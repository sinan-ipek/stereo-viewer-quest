# StereoViewer for Meta Quest

StereoGuide'ın yan yana (SBS / parallel) fotoğraflarını Quest'te üç boyutlu gösteren sade, çevrimdışı görüntüleyici.

## Kullanım

1. SBS JPG dosyalarını Quest'in `Pictures` veya `Pictures/StereoGuide` klasörüne kopyalayın.
2. APK'yı Quest'e SideQuest veya ADB ile kurun.
3. Uygulamayı `Unknown Sources / Bilinmeyen Kaynaklar` bölümünden açın.
4. İlk açılışta fotoğraf erişimine izin verin.

Kontroller: sağ/sol sonraki-önceki fotoğraf, Enter/A düğmesi gözleri değiştirir, yukarı/aşağı görüntüyü büyütüp küçültür.

