extends Node3D

@onready var photo: MeshInstance3D = $XROrigin3D/XRCamera3D/Photo
@onready var status: Label = $Status

var files: Array[String] = []
var current_index := 0
var swapped := false

func _ready() -> void:
	start_xr()
	request_storage_permission()
	await get_tree().create_timer(1.0).timeout
	scan_photos()
	if files.is_empty():
		status.text = "SBS fotoğraf bulunamadı. Fotoğrafı Quest/Pictures klasörüne kopyalayın."
	else:
		current_index = files.size() - 1
		show_current()

func start_xr() -> void:
	var xr = XRServer.find_interface("OpenXR")
	if xr and xr.is_initialized():
		get_viewport().use_xr = true
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	else:
		$FallbackCamera.current = true

func request_storage_permission() -> void:
	if OS.get_name() == "Android":
		OS.request_permissions()

func scan_photos() -> void:
	files.clear()
	var roots := [
		"/storage/emulated/0/Pictures/StereoGuide",
		"/storage/emulated/0/Pictures",
		"/sdcard/Pictures/StereoGuide",
		"/sdcard/Pictures"
	]
	for root in roots:
		collect_images(root)
	files.sort()

func collect_images(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	var name := dir.get_next()
	while name != "":
		if not dir.current_is_dir():
			var ext := name.get_extension().to_lower()
			var full := path.path_join(name)
			if ext in ["jpg", "jpeg", "png"] and not files.has(full):
				files.append(full)
		name = dir.get_next()
	dir.list_dir_end()

func show_current() -> void:
	if files.is_empty(): return
	var image := Image.new()
	var err := image.load(files[current_index])
	if err != OK:
		status.text = "Fotoğraf açılamadı: " + files[current_index].get_file()
		return
	var texture := ImageTexture.create_from_image(image)
	var material := photo.get_active_material(0) as ShaderMaterial
	material.set_shader_parameter("stereo_photo", texture)
	material.set_shader_parameter("swap_eyes", swapped)
	var half_ratio := (float(image.get_width()) * 0.5) / float(image.get_height())
	photo.scale.x = half_ratio / (16.0 / 9.0)
	status.text = "%d/%d  %s\nSağ/sol: fotoğraf  |  Enter: gözleri değiştir  |  Yukarı/aşağı: boyut" % [current_index + 1, files.size(), files[current_index].get_file()]

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_right"):
		current_index = (current_index + 1) % files.size() if not files.is_empty() else 0
		show_current()
	elif event.is_action_pressed("ui_left"):
		current_index = (current_index - 1 + files.size()) % files.size() if not files.is_empty() else 0
		show_current()
	elif event.is_action_pressed("ui_accept"):
		swapped = not swapped
		show_current()
	elif event.is_action_pressed("ui_up"):
		photo.scale *= 1.08
	elif event.is_action_pressed("ui_down"):
		photo.scale *= 0.92

